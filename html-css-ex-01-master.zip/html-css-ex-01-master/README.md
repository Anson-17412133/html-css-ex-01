# html-css-ex-01
Web Development Basic

- fork & clone the repo
- checkout branch with your student id
- create duplicate and rename the test.html file as [student id].html
- follow instructions and hints in the document
- commit and push
- send pull request
